# EmiMarket
Eine mobilefreundliche Kleinanzeigen-ähnliche Demo-Website.

Start:
1. index.html öffnen.
2. Alles läuft ohne Server direkt im Browser.
3. Anzeigen, Favoriten und Filter funktionieren lokal während der Sitzung.

Für eine echte Plattform wären später Datenbank, Login, Bild-Upload, echte Nachrichten, sichere Authentifizierung und Hosting nötig.
